﻿using Pod5.Model;
using Microsoft.EntityFrameworkCore;

namespace Pod5.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<LogMessage> LogMessage { get; set; }
    }
}
