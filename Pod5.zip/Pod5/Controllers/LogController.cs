﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pod5.Model;
using System.Text.Json.Serialization;
using Pod5.Data;

namespace Pod5.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LogController : ControllerBase
    {
        private string logFileDirectory = "Logs";
        private readonly AppDbContext _appDbContext;

        

        public string Log(string message, string logFilePath = "Logs")
        {
            using (StreamWriter streamWriter = new StreamWriter(logFilePath, true))  // true to append data to the file
            {
                streamWriter.WriteLine($"{DateTime.Now}: {message}");
            }
            return "success";
        }


        public async Task<IActionResult> PostLogEntry([FromBody] LogMessage logMessage)
        {
            try
            {
                // Save to database
                _appDbContext.LogMessage.Add(logMessage);
                await _appDbContext.SaveChangesAsync();
                // Save to file

                string LogM = logMessage.ToString();
                Log(LogM, logFileDirectory);

                return Ok();
            }
            catch (Exception ex)
            {
                // Log the exception details
               
                return StatusCode(500, "Internal server error");
            }
        }
    }
}