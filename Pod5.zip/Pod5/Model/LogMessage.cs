﻿namespace Pod5.Model
{
    public class LogMessage
    {
        public int AssociateId { get; set; }
        public string? Message { get; set; }
        public string? LogSeverity{ get; set; }

        public string? LogLevel { get; set; }   

        public string? HostName { get; set; }   

        public  string? Technology { get; set; }

        public string? ModuleName { get; set; } 

        public string? FeatureName { get; set; }

        public string? ClassName { get; set; }

        public int? ErrorCode { get; set; } 

        public string? ErrorMessage { get; set; }
        
        public DateTime Timestamp { get; set; }
        
    }
}
